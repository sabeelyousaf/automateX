<div class="table-responsive text-nowrap">

    
  <div class="container py-5">
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-lg-3 col-md-6 col-sm-12">
            <div class="p-0 border rounded-3">
            <div class="image-handler">
                <img src="<?php echo e(asset('assets/banners/'.$item->img)); ?>" style="height: 200px;object-fit:cover;" class="w-100 rounded-3" alt="">
            </div>
            <div class="py-3 px-2  d-flex justify-content-center">
                <a href="<?php echo e(asset('assets/banners/'.$item->img)); ?>"><i class="ti ti-eye fs-5 text-white btn btn-info me-3" style="cursor: pointer"></i></a>  <a href="<?php echo e(route('delete-banner',['id'=>$item->id])); ?>"><i class="ti ti-trash fs-5 text-white btn btn-danger" style="cursor: pointer"></i></a><a href="<?php echo e(route('edit-banner',['id'=>$item->id])); ?>"><i data-bs-toggle="modal" data-bs-target="#ledger_7" style="cursor: pointer" class="ti ti-pencil fs-5 mx-3 text-white btn btn-warning"></i></a>
            </div>
        </div>
    </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <?php endif; ?>

      </div>
  </div>

</div>
<?php /**PATH /home/u247318372/domains/miyar.pk/public_html/hillview/resources/views/backend_app/banners/partials/_banner_box.blade.php ENDPATH**/ ?>