<?php $__env->startSection('content'); ?>

<div class="layout-page">
    <!-- Navbar -->

    <?php echo $__env->make('backend_app.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- / Navbar -->
   <?php
function format_currency_with_commas($amount) {
    return 'Pkr: ' . number_format($amount);
}
?>


    <!-- Content wrapper -->
    <div class="content-wrapper">
      <!-- Content -->

      <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
          <!-- Website Analytics -->
          <div class="col-lg-6 mb-4 ">
            <div
              class="swiper-container swiper-container-horizontal swiper  card"

              id="swiper-with-pagination-cards">
              <div class="swiper-wrapper">
                <div class="swiper-slide">
                  <div class="row">
                    <div class="col-12">
                      <h5 class="text-white mb-0 mt-2 mb-4">Files Summary</h5>

                    </div>
                    <div class="row">
                      <div class="col-lg-12 col-md-12 col-12 order-2 order-md-1">

                        <div class="row">
                          <div class="col-6">
                            <ul class="list-unstyled mb-0">
                                <li class="d-flex mb-2 align-items-center">

                                    <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75">
                                        <a class="text-white" href="<?php echo e(route('all-files')); ?>" >Total Files</a>
                                   </p>


                                  </li>
                                  <li class="d-flex align-items-center mb-2">
                                    <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75"><a class="text-white" href="<?php echo e(route('file_status',['status'=>"open"])); ?>">Open Files</a></p>

                                  </li>
                              <li class="d-flex align-items-center mb-2">
                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75"><a class="text-white" href="<?php echo e(route('file_status',['status'=>"closed"])); ?>">Closed Files</a></p>

                              </li>

                              <li class="d-flex align-items-center mb-2">
                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75"><a class="text-white" href="<?php echo e(route('file_status',['status'=>"ready"])); ?>">Ready Files</a></p>

                              </li>
                              <li class="d-flex align-items-center mb-2">
                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75"><a class="text-white" href="<?php echo e(route('file_status',['status'=>"processing"])); ?>">In Process Files</a></p>

                              </li>
                              <li class="d-flex align-items-center mb-2">
                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75"><a class="text-white" href="<?php echo e(route('file_status',['status'=>"blocked"])); ?>">Blocked Files</a></p>

                              </li>
                              <li class="d-flex align-items-center mb-2">
                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75"><a class="text-white" href="<?php echo e(route('file_status',['status'=>"delivered"])); ?>">Delivered Files</a></p>

                              </li>
                              <li class="d-flex align-items-center mb-2">
                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75"><a class="text-white" href="<?php echo e(route('file_status',['status'=>"reserved"])); ?>">Reserved Files</a></p>

                              </li>
                            </ul>
                          </div>
                          <div class="col-6">
                            <ul class="list-unstyled mb-0">

                              <li class="d-flex mb-2 align-items-center">
                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price">
                                    <?php echo e($total_files); ?>

                                  </p>

                              </li>
                              <li class="d-flex align-items-center mb-2">
                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price">
                                    <?php echo e($open_files); ?>

                                    

                              </li>
                              <li class="d-flex align-items-center mb-2">
                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price"><?php echo e($closed_files); ?></p>

                              </li>
                                                            <li class="d-flex align-items-center mb-2">
                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price"><?php echo e($ready_files); ?></p>

                              </li>
                              <li class="d-flex align-items-center mb-2">
                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price"><?php echo e($processing_files); ?></p>

                              </li>
                              <li class="d-flex align-items-center mb-2">
                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price"><?php echo e($blocked_files); ?></p>

                              </li>
                              <li class="d-flex align-items-center mb-2">
                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price"><?php echo e($delivered_files); ?></p>

                              </li>
                              <li class="d-flex align-items-center mb-2">
                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price"><?php echo e($reserved_files); ?></p>

                              </li>
                            </ul>
                          </div>

                        </div>
                      </div>

                    </div>
                  </div>
                </div>
                <div class="swiper-slide">
                  <div class="row">
                    <div class="col-12">
                      <h5 class="text-white mb-0 mt-2">Website Analytics</h5>
                      <small>Total 28.5% Conversion Rate</small>
                    </div>
                    <div class="col-lg-7 col-md-9 col-12 order-2 order-md-1">
                      <h6 class="text-white mt-0 mt-md-3 mb-3">Spending</h6>
                      <div class="row">
                        <div class="col-6">
                          <ul class="list-unstyled mb-0">
                            <li class="d-flex mb-4 align-items-center">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start">12h</p>
                              <p class="mb-0">Spend</p>
                            </li>
                            <li class="d-flex align-items-center mb-2">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start">127</p>
                              <p class="mb-0">Order</p>
                            </li>
                          </ul>
                        </div>
                        <div class="col-6">
                          <ul class="list-unstyled mb-0">
                            <li class="d-flex mb-4 align-items-center">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start">18</p>
                              <p class="mb-0">Order Size</p>
                            </li>
                            <li class="d-flex align-items-center mb-2">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start">2.3k</p>
                              <p class="mb-0">Items</p>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-5 col-md-3 col-12 order-1 order-md-2 my-4 my-md-0 text-center">
                      <img
                        src="<?php echo e(asset("assets/img/illustrations/card-website-analytics-2.png" )); ?>"
                        alt="Website Analytics"
                        width="170"
                        class="card-website-analytics-img" />
                    </div>
                  </div>
                </div>
                <div class="swiper-slide">
                  <div class="row">
                    <div class="col-12">
                      <h5 class="text-white mb-0 mt-2">Website Analytics</h5>
                      <small>Total 28.5% Conversion Rate</small>
                    </div>
                    <div class="col-lg-7 col-md-9 col-12 order-2 order-md-1">
                      <h6 class="text-white mt-0 mt-md-3 mb-3">Revenue Sources</h6>
                      <div class="row">
                        <div class="col-6">
                          <ul class="list-unstyled mb-0">
                            <li class="d-flex mb-4 align-items-center">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start">268</p>
                              <p class="mb-0">Direct</p>
                            </li>
                            <li class="d-flex align-items-center mb-2">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start">62</p>
                              <p class="mb-0">Referral</p>
                            </li>
                          </ul>
                        </div>
                        <div class="col-6">
                          <ul class="list-unstyled mb-0">
                            <li class="d-flex mb-4 align-items-center">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start">890</p>
                              <p class="mb-0">Organic</p>
                            </li>
                            <li class="d-flex align-items-center mb-2">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start">1.2k</p>
                              <p class="mb-0">Campaign</p>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-5 col-md-3 col-12 order-1 order-md-2 my-4 my-md-0 text-center">
                      <img
                        src="<?php echo e(asset("assets/img/illustrations/card-website-analytics-3.png" )); ?>"
                        alt="Website Analytics"
                        width="170"
                        class="card-website-analytics-img" />
                    </div>
                  </div>
                </div>
              </div>
              <div class="swiper-pagination"></div>
            </div>
          </div>
          <!--/ Website Analytics -->

          <!-- Sales Overview -->
          <div class="col-lg-6 mb-4 ">
            <div
              class="swiper-container swiper-container-horizontal swiper card mb-2"

              id="swiper-with-pagination-cards">
              <div class="swiper-wrapper">
                <div class="swiper-slide">
                  <div class="row">
                    <div class="col-12">
                      <h5 class="text-white mb-0 mt-2 mb-4">Project Amount</h5>

                    </div>
                    <div class="row">
                      <div class="col-lg-12 col-md-12 col-12 order-2 order-md-1">

                        <div class="row">
                          <div class="col-6">
                            <ul class="list-unstyled mb-0">
                                <li class="d-flex mb-2 align-items-center">

                                    <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75">
                                        <a class="text-white">Booking Amount</a>
                                   </p>


                                  </li>
                                  <li class="d-flex align-items-center mb-2">
                                    <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75"><a class="text-white" >Paid Amount</a></p>

                                  </li>
                              <li class="d-flex align-items-center mb-2">
                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75"><a class="text-white">Balance Amount</a></p>

                              </li>


                            </ul>
                          </div>
                          <div class="col-6">
                            <ul class="list-unstyled mb-0">

                              <li class="d-flex mb-2 align-items-center">
                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price price">
                                    <?php echo e($total_booking_amount); ?>

                                  </p>

                              </li>
                              <li class="d-flex align-items-center mb-2">
                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price price">
                                    <?php echo e($total_paid_amount); ?>

                                    

                              </li>
                              <li class="d-flex align-items-center mb-2">
                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price"><?php echo e($balance_amount); ?></p>


                            </ul>
                          </div>

                        </div>
                      </div>

                    </div>
                  </div>
                </div>

            </div>



          </div>
          <div
          class="swiper-container swiper-container-horizontal swiper  card mt-1 "

          id="swiper-with-pagination-cards">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="row">
                <div class="col-12">
                  <h5 class="text-white mb-0 mt-2 mb-4">Project Details</h5>

                </div>
                <div class="row">
                  <div class="col-lg-12 col-md-12 col-12 order-2 order-md-1">

                    <div class="row">
                      <div class="col-6">
                        <ul class="list-unstyled mb-0">
                            <li class="d-flex mb-2 align-items-center">

                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75">
                                    <a class="text-white">Sales Partner</a>
                               </p>


                              </li>
                              <li class="d-flex align-items-center mb-2">
                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75"><a class="text-white" >Total Clients</a></p>

                              </li>



                        </ul>
                      </div>
                      <div class="col-6">
                        <ul class="list-unstyled mb-0">

                          <li class="d-flex mb-2 align-items-center">
                            <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price">
                                <?php echo e($total_sales_partners); ?>

                              </p>

                          </li>
                          <li class="d-flex align-items-center mb-2">
                            <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price">
                                <?php echo e($total_clients); ?>

                                

                          </li>


                        </ul>
                      </div>

                    </div>
                  </div>

                </div>
              </div>
            </div>

          </div>

        </div>

        </div>
      </div>
      <!-- / Content -->

      <div class="row">
        <!-- Website Analytics -->
        <div class="col-lg-6 mb-4 ">
          <div
            class="swiper-container swiper-container-horizontal swiper  card"

            id="swiper-with-pagination-cards">
            <div class="swiper-wrapper">
              <div class="swiper-slide">
                <div class="row">
                  <div class="col-12">
                    <h5 class="text-white mb-0 mt-2 mb-4">Total Files By Category</h5>

                  </div>
                  <div class="row">
                    <div class="col-lg-12 col-md-12 col-12 order-2 order-md-1">

                      <div class="row">
                        <div class="col-6">
                          <ul class="list-unstyled mb-0">
                              <li class="d-flex mb-2 align-items-center">

                                  <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75">
                                      <a class="text-white">4 Marla</a>
                                 </p>


                                </li>
                                <li class="d-flex align-items-center mb-2">
                                  <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75"><a class="text-white" >5 Marla</a></p>

                                </li>
                            <li class="d-flex align-items-center mb-2">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75"><a class="text-white" >6 Marla</a></p>

                            </li>

                            <li class="d-flex align-items-center mb-2">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75"><a class="text-white">8 Marla</a></p>

                            </li>
                            <li class="d-flex align-items-center mb-2">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75"><a class="text-white" >10 Marla</a></p>

                            </li>
                            <li class="d-flex align-items-center mb-2">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75"><a class="text-white" >12 Marla</a></p>

                            </li>
                            <li class="d-flex align-items-center mb-2">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75"><a class="text-white" >18 Marla</a></p>

                            </li>
                            <li class="d-flex align-items-center mb-2">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75"><a class="text-white" >20 Marla</a></p>

                            </li>
                          </ul>
                        </div>
                        <div class="col-6">
                          <ul class="list-unstyled mb-0">

                            <li class="d-flex mb-2 align-items-center">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price">
                                  <?php echo e($total_4marla); ?>

                                </p>

                            </li>
                            <li class="d-flex align-items-center mb-2">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price">
                                  <?php echo e($total_5marla); ?>

                                  

                            </li>
                            <li class="d-flex align-items-center mb-2">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price"><?php echo e($total_6marla); ?></p>

                            </li>
                                                          <li class="d-flex align-items-center mb-2">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price"><?php echo e($total_8marla); ?></p>

                            </li>
                            <li class="d-flex align-items-center mb-2">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price"><?php echo e($total_10marla); ?></p>

                            </li>
                            <li class="d-flex align-items-center mb-2">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price"><?php echo e($total_12marla); ?></p>

                            </li>
                            <li class="d-flex align-items-center mb-2">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price"><?php echo e($total_18marla); ?></p>

                            </li>
                            <li class="d-flex align-items-center mb-2">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price"><?php echo e($total_20marla); ?></p>

                            </li>
                          </ul>
                        </div>

                      </div>
                    </div>

                  </div>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="row">
                  <div class="col-12">
                    <h5 class="text-white mb-0 mt-2">Website Analytics</h5>
                    <small>Total 28.5% Conversion Rate</small>
                  </div>
                  <div class="col-lg-7 col-md-9 col-12 order-2 order-md-1">
                    <h6 class="text-white mt-0 mt-md-3 mb-3">Spending</h6>
                    <div class="row">
                      <div class="col-6">
                        <ul class="list-unstyled mb-0">
                          <li class="d-flex mb-4 align-items-center">
                            <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start">12h</p>
                            <p class="mb-0">Spend</p>
                          </li>
                          <li class="d-flex align-items-center mb-2">
                            <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start">127</p>
                            <p class="mb-0">Order</p>
                          </li>
                        </ul>
                      </div>
                      <div class="col-6">
                        <ul class="list-unstyled mb-0">
                          <li class="d-flex mb-4 align-items-center">
                            <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start">18</p>
                            <p class="mb-0">Order Size</p>
                          </li>
                          <li class="d-flex align-items-center mb-2">
                            <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start">2.3k</p>
                            <p class="mb-0">Items</p>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-5 col-md-3 col-12 order-1 order-md-2 my-4 my-md-0 text-center">
                    <img
                      src="<?php echo e(asset("assets/img/illustrations/card-website-analytics-2.png" )); ?>"
                      alt="Website Analytics"
                      width="170"
                      class="card-website-analytics-img" />
                  </div>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="row">
                  <div class="col-12">
                    <h5 class="text-white mb-0 mt-2">Website Analytics</h5>
                    <small>Total 28.5% Conversion Rate</small>
                  </div>
                  <div class="col-lg-7 col-md-9 col-12 order-2 order-md-1">
                    <h6 class="text-white mt-0 mt-md-3 mb-3">Revenue Sources</h6>
                    <div class="row">
                      <div class="col-6">
                        <ul class="list-unstyled mb-0">
                          <li class="d-flex mb-4 align-items-center">
                            <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start">268</p>
                            <p class="mb-0">Direct</p>
                          </li>
                          <li class="d-flex align-items-center mb-2">
                            <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start">62</p>
                            <p class="mb-0">Referral</p>
                          </li>
                        </ul>
                      </div>
                      <div class="col-6">
                        <ul class="list-unstyled mb-0">
                          <li class="d-flex mb-4 align-items-center">
                            <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start">890</p>
                            <p class="mb-0">Organic</p>
                          </li>
                          <li class="d-flex align-items-center mb-2">
                            <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start">1.2k</p>
                            <p class="mb-0">Campaign</p>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-5 col-md-3 col-12 order-1 order-md-2 my-4 my-md-0 text-center">
                    <img
                      src="<?php echo e(asset("assets/img/illustrations/card-website-analytics-3.png" )); ?>"
                      alt="Website Analytics"
                      width="170"
                      class="card-website-analytics-img" />
                  </div>
                </div>
              </div>
            </div>
            <div class="swiper-pagination"></div>
          </div>
        </div>
        <!--/ Website Analytics -->

        <!-- Sales Overview -->
        <div class="col-lg-6 mb-4 ">
          <div
            class="swiper-container swiper-container-horizontal swiper card mb-2"

            id="swiper-with-pagination-cards">
            <div class="swiper-wrapper">
              <div class="swiper-slide">
                <div class="row">
                  <div class="col-12">
                    <h5 class="text-white mb-0 mt-2 mb-4">Total Open Files By Category</h5>

                  </div>
                  <div class="row">
                    <div class="col-lg-12 col-md-12 col-12 order-2 order-md-1">

                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-12 order-2 order-md-1">

                              <div class="row">
                                <div class="col-6">
                                  <ul class="list-unstyled mb-0">
                                      <li class="d-flex mb-2 align-items-center">

                                          <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75">
                                              <a class="text-white"  >4 Marla</a>
                                         </p>


                                        </li>
                                        <li class="d-flex align-items-center mb-2">
                                          <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75"><a class="text-white" >5 Marla</a></p>

                                        </li>
                                    <li class="d-flex align-items-center mb-2">
                                      <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75"><a class="text-white" >6 Marla</a></p>

                                    </li>

                                    <li class="d-flex align-items-center mb-2">
                                      <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75"><a class="text-white" >8 Marla</a></p>

                                    </li>
                                    <li class="d-flex align-items-center mb-2">
                                      <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75"><a class="text-white" >10 Marla</a></p>

                                    </li>
                                    <li class="d-flex align-items-center mb-2">
                                      <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75"><a class="text-white" >12 Marla</a></p>

                                    </li>
                                    <li class="d-flex align-items-center mb-2">
                                      <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75"><a class="text-white" >18 Marla</a></p>

                                    </li>
                                    <li class="d-flex align-items-center mb-2">
                                      <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75"><a class="text-white" >20 Marla</a></p>

                                    </li>
                                  </ul>
                                </div>
                                <div class="col-6">
                                  <ul class="list-unstyled mb-0">

                                    <li class="d-flex mb-2 align-items-center">
                                      <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price">
                                          <?php echo e($open_total_4marla); ?>

                                        </p>

                                    </li>
                                    <li class="d-flex align-items-center mb-2">
                                      <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price">
                                          <?php echo e($open_total_5marla); ?>

                                          

                                    </li>
                                    <li class="d-flex align-items-center mb-2">
                                      <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price"><?php echo e($open_total_6marla); ?></p>

                                    </li>
                                                                  <li class="d-flex align-items-center mb-2">
                                      <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price"><?php echo e($open_total_8marla); ?></p>

                                    </li>
                                    <li class="d-flex align-items-center mb-2">
                                      <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price"><?php echo e($open_total_10marla); ?></p>

                                    </li>
                                    <li class="d-flex align-items-center mb-2">
                                      <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price"><?php echo e($open_total_12marla); ?></p>

                                    </li>
                                    <li class="d-flex align-items-center mb-2">
                                      <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price"><?php echo e($open_total_18marla); ?></p>

                                    </li>
                                    <li class="d-flex align-items-center mb-2">
                                      <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price"><?php echo e($open_total_20marla); ?></p>

                                    </li>
                                  </ul>
                                </div>

                              </div>
                            </div>

                          </div>
                    </div>

                  </div>
                </div>
              </div>

          </div>



        </div>





    </div>
    <div class="col-lg-12 mb-4 ">
        <div
          class="swiper-container swiper-container-horizontal swiper card mb-2"

          id="swiper-with-pagination-cards">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="row">
                <div class="col-12">
                  <h5 class="text-white mb-0 mt-2 mb-4">Discount Forms</h5>

                </div>
                <div class="row">
                  <div class="col-lg-12 col-md-12 col-12 order-2 order-md-1">

                      <div class="row">
                          <div class="col-lg-12 col-md-12 col-12 order-2 order-md-1">

                            <div class="row">
                              <div class="col-6">
                                <ul class="list-unstyled mb-0">
                                    <li class="d-flex mb-2 align-items-center">

                                        <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75">
                                            <a class="text-white">Total Open Discount Forms</a>
                                       </p>


                                      </li>
                                      <li class="d-flex align-items-center mb-2">
                                        <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75"><a class="text-white" >Total Adjusted Discount Forms</a></p>

                                      </li>
                                  <li class="d-flex align-items-center mb-2">
                                    <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start bg-primary w-75"><a class="text-white">Total Blocked Discount Forms</a></p>

                                  </li>


                                </ul>
                              </div>
                              <div class="col-6">
                                <ul class="list-unstyled mb-0">

                                  <li class="d-flex mb-2 align-items-center">
                                    <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price price">
                                        <?php echo e($discount_total_forms); ?>

                                      </p>

                                  </li>
                                  <li class="d-flex align-items-center mb-2">
                                    <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price">
                                        <?php echo e($adjusted_discount_forms); ?>

                                        

                                  </li>
                                  <li class="d-flex align-items-center mb-2">
                                    <p class="mb-0 fw-medium me-2 website-analytics-text-bg text-start w-100 price"><?php echo e($adjusted_blocked_forms); ?></p>

                                  </li>

                                </ul>
                              </div>

                            </div>
                          </div>

                        </div>
                  </div>

                </div>
              </div>
            </div>

        </div>



      </div>


  </div>


      <!-- Footer -->
     <?php echo $__env->make('backend_app.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- / Footer -->

      <div class="content-backdrop fade"></div>
    </div>
    <!-- Content wrapper -->
  </div>
  <script>
    function number_format(number, decimals, dec_point, thousands_sep) {
    number = (number + '').replace(/[^0-9+\-Ee.]/g, '');
    var n = !isFinite(+number) ? 0 : +number,
        prec = !isFinite(+decimals) ? 0 : Math.abs(decimals),
        sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep,
        dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
        s = '',
        toFixedFix = function(n, prec) {
            var k = Math.pow(10, prec);
            return '' + Math.round(n * k) / k;
        };
    s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.');
    if (s[0].length > 3) {
        s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
    }
    if ((s[1] || '').length < prec) {
        s[1] = s[1] || '';
        s[1] += new Array(prec - s[1].length + 1).join('0');
    }
    return s.join(dec);
}
var prices = document.querySelectorAll('.price');
prices.forEach(function(priceElement) {
    var price = parseFloat(priceElement.textContent);
    var formattedPrice = number_format(price); // Assuming 2 decimal places
    priceElement.textContent = formattedPrice;
});
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend_app.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\hillview\hill-view\CRM\resources\views/backend_app/index.blade.php ENDPATH**/ ?>