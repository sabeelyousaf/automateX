<?php $__env->startSection('content'); ?>

<div class="layout-page">
    <!-- Navbar -->
    <?php echo $__env->make('backend_app.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- / Navbar -->

    <!-- Content wrapper -->
    <div class="content-wrapper">
      <!-- Content -->

      <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Files /</span> Add File</h4>

        <div class="card mb-3">
            <div class="card-datatable table-responsive p-4 ">

              <h5 class="pb-3">Import File Data From Excel File</h5>
              <div class="row">
                <form action="<?php echo e(route('import-excel')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="col-lg-12 col-sm-12 col-md-12">
                        <label for="">Attach File</label>
                        <input type="file" class="form-control" accept=".xlsx, .xls" name="excel_file" id="">
                    </div>
                    <div class="col-lg-12 col-sm-12 col-md-12">
                        <button class="btn btn-primary mt-3" type="submit">Import File</button>
                    </div>


                </div>
            </form>


            </div>
          </div>
          <div class="card mb-3">
            <div class="card-datatable table-responsive p-4 ">

              <p class="pb-3">Download the excel format from below link</p>


              <div class="row mt-3">
                  <div class="col-lg-12 col-sm-12 col-md-12">
                    <form action="<?php echo e(route('store-file')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <a href="<?php echo e(asset('assets/hill_view_file.xlsx')); ?>">Download Now</a>
                  </div>

              </div>


            </div>
          </div>

        <div class="card">
          <div class="card-datatable table-responsive p-4">

            <h5 class="pb-3">Add New File</h5>
            <div class="row">
                <div class="col-lg-6 col-sm-12 col-md-6">
                    <label for="">Form No</label>
                    <input type="text" class="form-control" name="form_no" id="">
                    <?php $__errorArgs = ['form_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-lg-6 col-sm-12 col-md-6">
                    <label for="">ID No</label>
                    <input type="text" class="form-control" name="id_no" id="">
                    <?php $__errorArgs = ['id_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


            </div>
            <div class="row mt-3">
                <div class="col-lg-6 col-sm-12 col-md-6">
                    <label for="">Security No</label>
                    <input type="text" class="form-control" name="security_no" id="">
                    <?php $__errorArgs = ['security_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-lg-6 col-sm-12 col-md-6">
                    <label for="">File Status</label>
                   <select name="file_status" class="form-select" id="">
                    <option value="">Choose...</option>
                    <option value="open">Open</option>
                    <option value="closed">Closed</option>
                    <option value="blocked">Blocked</option>
                    <option value="processing">Processing</option>
                    <option value="reserved">Reserved</option>
                    <option value="ready">Ready</option>
                   </select>
                </div>

            </div>

            <div class="row mt-3">
                <div class="col-lg-6 col-sm-12 col-md-6">
                    <label for="">Type</label>
                    <select name="type" class="form-select" id="">
                        <option value="">Choose...</option>
                        <option value="residential">Residential</option>
                        <option value="commercial">Commercial</option>
                       </select>
                       <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                       <span class="text-danger"><?php echo e($message); ?></span>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-lg-6 col-sm-12 col-md-6">
                    <label for="">Size</label>
                    <input type="number" name="size" class="form-control"  id="">
                    <?php $__errorArgs = ['size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

            </div>

            <div class="row mt-3">
                <div class="col-lg-6 col-sm-12 col-md-6">
                    <label for="">Unit</label>
                    <select name="unit" class="form-select" id="">
                        <option value="">Choose...</option>
                        <option value="marla">Marla</option>
                        <option value="kanal">Kanal</option>
                       </select>
                       <?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                       <span class="text-danger"><?php echo e($message); ?></span>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-lg-6 col-sm-12 col-md-6">
                    <label for="">Total Amount</label>
                    <input type="number" name="total_amount" class="form-control" id="">
                    <?php $__errorArgs = ['total_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

            </div>

            <div class="row mt-3">
                <div class="col-lg-6 col-sm-12 col-md-6">
                    <label for="">Paid Amount</label>
                    <input type="number" class="form-control" name="paid_amount" id="">
                    <?php $__errorArgs = ['paid_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-lg-6 col-sm-12 col-md-6">
                    <label for="">File Location</label>
                    <input type="text" class="form-control" name="file_location" id="">
                    <?php $__errorArgs = ['file_location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

            </div>

            <div class="row mt-3">

                <div class="col-lg-6 col-sm-12 col-md-6">
                    <label for="">Assign Distributor</label>
                    <select name="distributor_id" class="form-select" id="">
                        <option value="">Choose...</option>
                        <?php $__currentLoopData = $distributor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </select>
                       <?php $__errorArgs = ['distributor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                       <span class="text-danger"><?php echo e($message); ?></span>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

            </div>



            <div class="row mt-3">
                <div class="col-12">
                    <button class="btn btn-primary">Submit</button>
                </div>
            </div>
        </form>
          </div>
        </div>
        <!-- Modal to add new record -->

        <!--/ DataTable with Buttons -->



      </div>
      <!-- / Content -->

      <!-- Footer -->
  <?php echo $__env->make('backend_app.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- / Footer -->

      <div class="content-backdrop fade"></div>
    </div>
    <!-- Content wrapper -->
  </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend_app.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u669820646/domains/khybercity.com.pk/public_html/crm/resources/views/backend_app/add_file.blade.php ENDPATH**/ ?>