<?php $__env->startSection('content'); ?>

<div class="layout-page">
    <!-- Navbar -->

    <?php echo $__env->make('backend_app.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- / Navbar -->

    <!-- Content wrapper -->
    <div class="content-wrapper">
      <!-- Content -->

      <div class="container-xxl flex-grow-1 container-p-y">
        <div class="card">
          <!-- Pricing Plans -->
          <div class="pb-sm-5 pb-2 rounded-top">
            <div class="container py-5">
              <h2 class="text-center mb-2 mt-0 mt-md-4">Pricing Plans</h2>
              <p class="text-center">
                Get started with us - it's perfect for individuals and teams. Choose a subscription plan that
                meets your needs.
              </p>


              <div class="row mx-0 gy-3 px-lg-5 mt-3">
                <!-- Basic -->
                <div class="col-lg-4 mb-md-0 mb-4">
                  <div class="card border rounded shadow-none">
                    <div class="card-body">
                      <div class="my-3 pt-2 text-center">
                        <img
                          src="../../assets/img/illustrations/page-pricing-basic.png"
                          alt="Basic Image"
                          height="140" />
                      </div>
                      <h3 class="card-title text-center text-capitalize mb-1">Basic</h3>
                      <p class="text-center">A simple start for everyone</p>
                      <div class="text-center">
                        <div class="d-flex justify-content-center">
                          <sup class="h6 pricing-currency mt-3 mb-0 me-1 text-primary">$</sup>
                          <h1 class="display-4 mb-0 text-primary">0</h1>
                          <sub class="h6 pricing-duration mt-auto mb-2 text-muted fw-normal">/month</sub>
                        </div>
                      </div>

                      <ul class="ps-3 my-4 pt-2">
                        <li class="mb-2">100 responses a month</li>
                        <li class="mb-2">Unlimited forms and surveys</li>
                        <li class="mb-2">Unlimited fields</li>
                        <li class="mb-2">Basic form creation tools</li>
                        <li class="mb-0">Up to 2 subdomains</li>
                      </ul>

                      <a href="<?php echo e(route('billing')); ?>" class="btn btn-label-success d-grid w-100"
                        >Buy Now</a
                      >
                    </div>
                  </div>
                </div>

                <!-- Pro -->
                
              </div>
            </div>
          </div>
          <!--/ Pricing Plans -->
        </div>
      </div>
      <!-- / Content -->

      <!-- Footer -->
      <footer class="content-footer footer bg-footer-theme">
        <div class="container-xxl">
          <div
            class="footer-container d-flex align-items-center justify-content-between py-2 flex-md-row flex-column">
            <div>
              ©
              <script>
                document.write(new Date().getFullYear());
              </script>
              , made with ❤️ by <a href="https://pixinvent.com" target="_blank" class="fw-medium">Pixinvent</a>
            </div>
            <div class="d-none d-lg-inline-block">
              <a href="https://themeforest.net/licenses/standard" class="footer-link me-4" target="_blank"
                >License</a
              >
              <a href="https://1.envato.market/pixinvent_portfolio" target="_blank" class="footer-link me-4"
                >More Themes</a
              >

              <a
                href="https://demos.pixinvent.com/vuexy-html-admin-template/documentation/"
                target="_blank"
                class="footer-link me-4"
                >Documentation</a
              >

              <a href="https://pixinvent.ticksy.com/" target="_blank" class="footer-link d-none d-sm-inline-block"
                >Support</a
              >
            </div>
          </div>
        </div>
      </footer>
      <!-- / Footer -->

      <div class="content-backdrop fade"></div>
    </div>
    <!-- Content wrapper -->
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend_app.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\twitter\CRM\resources\views/backend_app/pricing.blade.php ENDPATH**/ ?>