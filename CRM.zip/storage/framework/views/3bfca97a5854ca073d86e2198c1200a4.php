<?php $__env->startSection('content'); ?>

<div class="layout-page">
    <!-- Navbar -->
    <?php echo $__env->make('backend_app.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- / Navbar -->

    <!-- Content wrapper -->
    <div class="content-wrapper">
      <!-- Content -->

      <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Clients /</span> All Clients</h4>

        <div class="row">
            <div class="col-12">
                <a href="<?php echo e(route('add-client')); ?>" class="btn btn-primary w-auto float-end mb-2">Add New Client +</a>
            </div>
        </div>
        <!-- DataTable with Buttons -->
        <div class="card">

            <div class="table-responsive text-nowrap">
                
                <table class="table">
                  <thead>
                    <tr class="text-nowrap">
                        <th><input type="checkbox" name="items[]"></th>
                        <th>Name </th>
                        
                        <th>Email </th>
                        <th>Address </th>

                        <th>Phone number</th>
                        <th>Date of birth.</th>
                        <th>Dealer Assign</th>

                        <th>Action</th>

                    </tr>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><input type="checkbox" name="items[]"></td>
                        <td><a href="<?php echo e(route('client-profile',['id'=>$item->id])); ?>"><?php echo e($item->name); ?></a></td>
                        
                        <td>
                            <?php echo e($item->email); ?>

                        </td>
                        <td><?php echo e($item->address); ?></td>
                        <td><?php echo e($item->phone_no); ?></td>
                        <td><?php echo e($item->date_of_birth); ?></td>
                        <td><?php echo e($item->distributor->name); ?></td>


                        <td>  <div class="dropdown">
                            <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                              <i class="ti ti-dots-vertical"></i>
                            </button>
                            <div class="dropdown-menu">
                              <a class="dropdown-item" href="<?php echo e(route('edit-client',['id'=>$item->id])); ?>"
                                ><i class="ti ti-pencil me-1"></i> Edit</a
                              >
                              <a class="dropdown-item"  href="<?php echo e(route('delete-client',['id'=>$item->id])); ?>"
                                ><i class="ti ti-trash me-1"></i> Delete</a
                              >
                            </div>
                          </div></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </thead>
               </table>
          </div>
        </div>
        <!-- Modal to add new record -->

        <!--/ DataTable with Buttons -->



      </div>
      <!-- / Content -->

      <!-- Footer -->
  <?php echo $__env->make('backend_app.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- / Footer -->

      <div class="content-backdrop fade"></div>
    </div>
    <!-- Content wrapper -->
  </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend_app.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\hillview\hill-view\resources\views/backend_app/all_clients.blade.php ENDPATH**/ ?>