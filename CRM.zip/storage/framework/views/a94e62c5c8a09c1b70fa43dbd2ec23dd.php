<?php $__env->startSection('content'); ?>

<div class="layout-page">
    <!-- Navbar -->
    <?php echo $__env->make('backend_app.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- / Navbar -->

    <!-- Content wrapper -->
    <div class="content-wrapper">
      <!-- Content -->

      <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light"><a href="<?php echo e(route('dashboard')); ?>">Dashboard </a> /</span> Customer Query </h4>


        <!-- DataTable with Buttons -->
        <div class="card">

            <div class="table-responsive text-nowrap">
                
                <table class="table">
                  <thead>
                    <tr class="text-nowrap">
                        <td><input type="checkbox" name="items[]"></td>
                        <th>Name </th>
                        <th>Last Name </th>
                        <th>City</th>
                        <th>Phone no</th>
                        <th>Email</th>
                        <th>Action</th>

                    </tr>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><input type="checkbox" name="items[]"></td>
                        <td><a href="<?php echo e(route('distributor-profile',['id'=>$item->id])); ?>" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Click to open dealer profile"><?php echo e($item->first_name); ?></a></td>
                        <td><?php echo e($item->last_name); ?></td>
                        <td><?php echo e($item->city); ?></td>
                        <td>
                            <?php echo e($item->phone_no); ?>

                        </td>
                        <td><?php echo e($item->city); ?></td>
                        <td>  <div class="dropdown">
                            <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                              <i class="ti ti-dots-vertical"></i>
                            </button>
                            <div class="dropdown-menu">
                              <a class="dropdown-item"  href="<?php echo e(route('delete-form',['id'=>$item->id])); ?>"
                                ><i class="ti ti-trash me-1"></i> Delete</a
                              >
                            </div>
                          </div></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </thead>
               </table>
          </div>
        </div>
        <div id="paginationContainer" class="float-end mt-3">
            <?php echo e($data->links()); ?>

         </div>
        <!-- Modal to add new record -->

        <!--/ DataTable with Buttons -->



      </div>
      <!-- / Content -->

      <!-- Footer -->
  <?php echo $__env->make('backend_app.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- / Footer -->

      <div class="content-backdrop fade"></div>
    </div>
    <!-- Content wrapper -->
  </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend_app.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\hillview\hill-view\CRM\resources\views/backend_app/forms/all_forms.blade.php ENDPATH**/ ?>