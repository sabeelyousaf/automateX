<?php $__env->startSection('content'); ?>

<div class="layout-page">
    <!-- Navbar -->
    <?php echo $__env->make('backend_app.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- / Navbar -->

    <!-- Content wrapper -->
    <div class="content-wrapper">
      <!-- Content -->

      <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Dealer /</span> All Dealers</h4>

        <div class="row">
            <div class="col-12">
                <a href="<?php echo e(route('add-dealer')); ?>" class="btn btn-primary w-auto float-end mb-2">Add New Dealer +</a>

            </div>
        </div>
        <!-- DataTable with Buttons -->
        <div class="card">

            <div class="table-responsive text-nowrap">
                
                <table class="table">
                  <thead>
                    <tr class="text-nowrap">
                        <td><input type="checkbox" name="items[]"></td>
                        <th>Company </th>
                        
                        
                        <th>Email </th>
                        <th>Name </th>

                        <th>Phone number</th>
                        <th>Date of birth.</th>

                        <th>CNIC</th>

                        <th>Action</th>

                    </tr>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><input type="checkbox" name="items[]"></td>
                        <td><a href="<?php echo e(route('distributor-profile',['id'=>$item->id])); ?>" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Click to open dealer profile"><?php echo e($item->company); ?></a></td>
                        
                        
                        <td>
                            <?php echo e($item->email); ?>

                        </td>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->phone_no); ?></td>
                        <td><?php echo e($item->date_of_birth); ?></td>
                        <td><?php echo e($item->cnic_no); ?></td>


                        <td>  <div class="dropdown">
                            <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                              <i class="ti ti-dots-vertical"></i>
                            </button>
                            <div class="dropdown-menu">
                              <a class="dropdown-item" href="<?php echo e(route('edit-dealer',['id'=>$item->id])); ?>"
                                ><i class="ti ti-pencil me-1"></i> Edit</a
                              >
                              <a class="dropdown-item"  href="<?php echo e(route('delete-dealer',['id'=>$item->id])); ?>"
                                ><i class="ti ti-trash me-1"></i> Delete</a
                              >
                            </div>
                          </div></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </thead>
               </table>
          </div>
        </div>
        <!-- Modal to add new record -->

        <!--/ DataTable with Buttons -->



      </div>
      <!-- / Content -->

      <!-- Footer -->
  <?php echo $__env->make('backend_app.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- / Footer -->

      <div class="content-backdrop fade"></div>
    </div>
    <!-- Content wrapper -->
  </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend_app.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u669820646/domains/khybercity.com.pk/public_html/crm/resources/views/backend_app/all_dealers.blade.php ENDPATH**/ ?>