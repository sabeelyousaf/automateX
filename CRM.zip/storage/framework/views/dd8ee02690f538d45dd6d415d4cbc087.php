<?php $__env->startSection('content'); ?>

<div class="layout-page">
    <!-- Navbar -->

    <?php echo $__env->make('backend_app.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- / Navbar -->
   <?php
function format_currency_with_commas($amount) {
    return 'Pkr: ' . number_format($amount);
}
?>


    <!-- Content wrapper -->
    <div class="content-wrapper">
      <!-- Content -->

      <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
          <!-- Website Analytics -->
          <div class="col-lg-6 mb-4">
            <div
              class="swiper-container swiper-container-horizontal swiper swiper-card-advance-bg"
              id="swiper-with-pagination-cards">
              <div class="swiper-wrapper">
                <div class="swiper-slide">
                  <div class="row">
                    <div class="col-12">
                      <h5 class="text-white mb-0 mt-2">Files Summary</h5>

                    </div>
                    <div class="row">
                      <div class="col-lg-7 col-md-9 col-12 order-2 order-md-1">
                        <h6 class="text-white mt-0 mt-md-3 mb-3">Detail</h6>
                        <div class="row">
                          <div class="col-6">
                            <ul class="list-unstyled mb-0">
                              <li class="d-flex mb-2 align-items-center">

                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg"><?php echo e($pending_files); ?></p>
                                <p class="mb-0"><a class="text-white" href="<?php echo e(route('file_status',['status'=>"processing"])); ?>">processing</a></p>

                              </li>
                              <li class="d-flex align-items-center mb-2">
                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg"><?php echo e($closed_files); ?></p>
                                <p class="mb-0"><a class="text-white" href="<?php echo e(route('file_status',['status'=>"closed"])); ?>">Closed</a></p>
                              </li>
                              <li class="d-flex align-items-center mb-2">
                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg"><?php echo e($ready_files); ?></p>
                                <p class="mb-0"><a class="text-white" href="<?php echo e(route('file_status',['status'=>"ready"])); ?>">Ready</a></p>
                              </li>
                            </ul>
                          </div>
                          <div class="col-6">
                            <ul class="list-unstyled mb-0">
                              <li class="d-flex mb-2 align-items-center">
                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg"><?php echo e($reserved_files); ?></p>
                                <p class="mb-0"><a class="text-white" href="<?php echo e(route('file_status',['status'=>"reserved"])); ?>">reserved</a></p>
                              </li>
                              <li class="d-flex align-items-center mb-2">
                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg"><?php echo e($open_files); ?></p>
                                <p class="mb-0"><a class="text-white" href="<?php echo e(route('file_status',['status'=>"open"])); ?>">Open</a></p>
                              </li>
                              <li class="d-flex align-items-center mb-2">
                                <p class="mb-0 fw-medium me-2 website-analytics-text-bg"><?php echo e($delivered_files); ?></p>
                                <p class="mb-0"><a class="text-white" href="<?php echo e(route('file_status',['status'=>"delivered"])); ?>">Delivered</a></p>
                              </li>
                            </ul>
                          </div>

                        </div>
                      </div>
                      <div class="col-lg-5 col-md-3 col-12 order-1 order-md-2 my-4 my-md-0 text-center">
                        <img
                          src="<?php echo e(asset("assets/img/file_hillview.png" )); ?>"
                          alt="Website Analytics"
                          width="170"
                          class="card-website-analytics-img" />
                      </div>
                    </div>
                  </div>
                </div>
                <div class="swiper-slide">
                  <div class="row">
                    <div class="col-12">
                      <h5 class="text-white mb-0 mt-2">Website Analytics</h5>
                      <small>Total 28.5% Conversion Rate</small>
                    </div>
                    <div class="col-lg-7 col-md-9 col-12 order-2 order-md-1">
                      <h6 class="text-white mt-0 mt-md-3 mb-3">Spending</h6>
                      <div class="row">
                        <div class="col-6">
                          <ul class="list-unstyled mb-0">
                            <li class="d-flex mb-4 align-items-center">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg">12h</p>
                              <p class="mb-0">Spend</p>
                            </li>
                            <li class="d-flex align-items-center mb-2">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg">127</p>
                              <p class="mb-0">Order</p>
                            </li>
                          </ul>
                        </div>
                        <div class="col-6">
                          <ul class="list-unstyled mb-0">
                            <li class="d-flex mb-4 align-items-center">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg">18</p>
                              <p class="mb-0">Order Size</p>
                            </li>
                            <li class="d-flex align-items-center mb-2">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg">2.3k</p>
                              <p class="mb-0">Items</p>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-5 col-md-3 col-12 order-1 order-md-2 my-4 my-md-0 text-center">
                      <img
                        src="<?php echo e(asset("assets/img/illustrations/card-website-analytics-2.png" )); ?>"
                        alt="Website Analytics"
                        width="170"
                        class="card-website-analytics-img" />
                    </div>
                  </div>
                </div>
                <div class="swiper-slide">
                  <div class="row">
                    <div class="col-12">
                      <h5 class="text-white mb-0 mt-2">Website Analytics</h5>
                      <small>Total 28.5% Conversion Rate</small>
                    </div>
                    <div class="col-lg-7 col-md-9 col-12 order-2 order-md-1">
                      <h6 class="text-white mt-0 mt-md-3 mb-3">Revenue Sources</h6>
                      <div class="row">
                        <div class="col-6">
                          <ul class="list-unstyled mb-0">
                            <li class="d-flex mb-4 align-items-center">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg">268</p>
                              <p class="mb-0">Direct</p>
                            </li>
                            <li class="d-flex align-items-center mb-2">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg">62</p>
                              <p class="mb-0">Referral</p>
                            </li>
                          </ul>
                        </div>
                        <div class="col-6">
                          <ul class="list-unstyled mb-0">
                            <li class="d-flex mb-4 align-items-center">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg">890</p>
                              <p class="mb-0">Organic</p>
                            </li>
                            <li class="d-flex align-items-center mb-2">
                              <p class="mb-0 fw-medium me-2 website-analytics-text-bg">1.2k</p>
                              <p class="mb-0">Campaign</p>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-5 col-md-3 col-12 order-1 order-md-2 my-4 my-md-0 text-center">
                      <img
                        src="<?php echo e(asset("assets/img/illustrations/card-website-analytics-3.png" )); ?>"
                        alt="Website Analytics"
                        width="170"
                        class="card-website-analytics-img" />
                    </div>
                  </div>
                </div>
              </div>
              <div class="swiper-pagination"></div>
            </div>
          </div>
          <!--/ Website Analytics -->

          <!-- Sales Overview -->
          <div class="col-lg-6 col-sm-6 mb-4">
            <div class="card">
              <div class="card-header">
                <div class="d-flex justify-content-between">
                  <small class="d-block mb-1 text-muted">Total Files Amount</small>

                </div>
                <h4 class="card-title mb-1"><?php echo e(format_currency_with_commas($total_files_amount)); ?></h4>
              </div>
              <div class="card-body">
                <div class="row">
                  <div class="col-4">
                    <div class="d-flex gap-2 align-items-center mb-2">
                      <span class="badge bg-label-info p-1 rounded"
                        ><i class="ti ti-shopping-cart ti-xs"></i
                      ></span>
                      <p class="mb-0">Paid</p>
                    </div>
                    <h5 class="mb-0 pt-1 text-nowrap"><?php echo e(format_currency_with_commas($total_paid_amount)); ?></h5>
                    <small class="text-muted"></small>
                  </div>
                  <div class="col-4">
                    <div class="divider divider-vertical">
                      <div class="divider-text">
                        <span class="badge-divider-bg bg-label-secondary">VS</span>
                      </div>
                    </div>
                  </div>
                  <div class="col-4 text-end">
                    <div class="d-flex gap-2 justify-content-end align-items-center mb-2">
                      <p class="mb-0">Unpaid</p>
                      <span class="badge bg-label-primary p-1 rounded"><i class="ti ti-link ti-xs"></i></span>
                    </div>
                    <h5 class="mb-0 pt-1 text-nowrap ms-lg-n3 ms-xl-0"><?php echo e(format_currency_with_commas($total_unpaid_amount)); ?></h5>

                  </div>
                </div>
                <div class="d-flex align-items-center mt-4">
                  <div class="progress w-100" style="height: 8px">
                    <div
                      class="progress-bar bg-info"
                      style="width: 70%"
                      role="progressbar"
                      aria-valuenow="70"
                      aria-valuemin="0"
                      aria-valuemax="100"></div>
                    <div
                      class="progress-bar bg-primary"
                      role="progressbar"
                      style="width: 30%"
                      aria-valuenow="30"
                      aria-valuemin="0"
                      aria-valuemax="100"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!--/ Sales Overview -->

          <!-- Revenue Generated -->
          <div class="col-12 col-xl-4 mb-4 col-md-6">
            <div class="card">
              <div class="card-header d-flex justify-content-between pb-1">
                <h5 class="mb-0 card-title">Total Files </h5>
                <div class="dropdown">
                  <button
                    class="btn p-0"
                    type="button"
                    id="totalEarning"
                    data-bs-toggle="dropdown"
                    aria-haspopup="true"
                    aria-expanded="false">
                    <i class="ti ti-dots-vertical ti-sm text-muted"></i>
                  </button>
                  <div class="dropdown-menu dropdown-menu-end" aria-labelledby="totalEarning">
                    <a class="dropdown-item" href="javascript:void(0);">View More</a>
                    <a class="dropdown-item" href="javascript:void(0);">Delete</a>
                  </div>
                </div>
              </div>
              <div class="card-body">
                <div class="d-flex align-items-center">
                  <h1 class="mb-0 me-2"><?php echo e($total_files); ?></h1>
                  <i class="ti ti-chevron-up text-success me-1"></i>

                </div>
                <div id="totalEarningChart"></div>
                

              </div>
            </div>
          </div>
          <!--/ Revenue Generated -->

          <!-- Earning Reports -->
          
          <!--/ Earning Reports -->

          <!-- Support Tracker -->
          
          <!--/ Support Tracker -->

          <!-- Sales By Country -->
          
          <!--/ Sales By Country -->

          <!-- Total Earning -->

          <!--/ Total Earning -->

          <!-- Monthly Campaign State -->
          
          <!--/ Monthly Campaign State -->

          <!-- Source Visit -->

          <!--/ Source Visit -->

          <!-- Projects table -->
          
          <!--/ Projects table -->


          <div class="col-12 col-xl-4 mb-4 col-md-6">
            <div class="card">
              <div class="card-header d-flex justify-content-between pb-1">
                <h5 class="mb-0 card-title">Total Sales Partners</h5>
                <div class="dropdown">
                  <button
                    class="btn p-0"
                    type="button"
                    id="totalEarning"
                    data-bs-toggle="dropdown"
                    aria-haspopup="true"
                    aria-expanded="false">
                    <i class="ti ti-dots-vertical ti-sm text-muted"></i>
                  </button>
                  <div class="dropdown-menu dropdown-menu-end" aria-labelledby="totalEarning">
                    <a class="dropdown-item" href="javascript:void(0);">View More</a>
                    <a class="dropdown-item" href="javascript:void(0);">Delete</a>
                  </div>
                </div>
              </div>
              <div class="card-body">
                <div class="d-flex align-items-center">
                  <h1 class="mb-0 me-2"><?php echo e($total_dealers); ?></h1>
                  <i class="ti ti-chevron-up text-success me-1"></i>

                </div>
                <div id="totalEarningChart"></div>
                

              </div>
            </div>
          </div>

          <div class="col-12 col-xl-4 mb-4 col-md-6">
            <div class="card">
              <div class="card-header d-flex justify-content-between pb-1">
                <h5 class="mb-0 card-title">Total Clients</h5>
                <div class="dropdown">
                  <button
                    class="btn p-0"
                    type="button"
                    id="totalEarning"
                    data-bs-toggle="dropdown"
                    aria-haspopup="true"
                    aria-expanded="false">
                    <i class="ti ti-dots-vertical ti-sm text-muted"></i>
                  </button>
                  <div class="dropdown-menu dropdown-menu-end" aria-labelledby="totalEarning">
                    <a class="dropdown-item" href="javascript:void(0);">View More</a>
                    <a class="dropdown-item" href="javascript:void(0);">Delete</a>
                  </div>
                </div>
              </div>
              <div class="card-body">
                <div class="d-flex align-items-center">
                  <h1 class="mb-0 me-2"><?php echo e($total_clients); ?></h1>
                  <i class="ti ti-chevron-up text-success me-1"></i>

                </div>
                <div id="totalEarningChart"></div>
                

              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- / Content -->

      <!-- Footer -->
     <?php echo $__env->make('backend_app.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- / Footer -->

      <div class="content-backdrop fade"></div>
    </div>
    <!-- Content wrapper -->
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend_app.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u669820646/domains/khybercity.com.pk/public_html/crm/resources/views/backend_app/index.blade.php ENDPATH**/ ?>