<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
   <?php
       $user=Auth::user();
   ?>
    <div class="app-brand demo">
      <a href="index.html" class="app-brand-link py-5">
        <img src="<?php echo e(asset('assets/img/logo/hillview-png-1.png')); ?>"  class="w-50 m-auto d-block">
      </a>

      <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto">
        <i class="ti menu-toggle-icon d-none d-xl-block ti-sm align-middle"></i>
        <i class="ti ti-x d-block d-xl-none ti-sm align-middle"></i>
      </a>
    </div>

    <div class="menu-inner-shadow"></div>
    <ul class="menu-inner py-1">
      <!-- Dashboards -->
      <li class="menu-item active ">
        <a href="<?php echo e(route('dashboard')); ?>" class="menu-link" >
          <i class="menu-icon tf-icons ti ti-smart-home"></i>
          <div >Dashboards</div>

        </a>

      </li>


      <!-- Layouts -->
      <li class="menu-item">
        <a href="javascript:void(0);" class="menu-link menu-toggle">
          <i class="menu-icon tf-icons ti ti-chart-pie"></i>
          <div >File Modules</div>
        </a>

        <ul class="menu-sub">
          <li class="menu-item">
            <a href="<?php echo e(route('add-files')); ?>" class="menu-link">
              <div >Add New File</div>
            </a>
          </li>
          <li class="menu-item">
            <a href="<?php echo e(route('all-files')); ?>" class="menu-link">
              <div >View All Files</div>
            </a>
          </li>

        </ul>
      </li>


      <li class="menu-item">
        <a href="javascript:void(0);" class="menu-link menu-toggle">
          <i class="menu-icon tf-icons ti ti-layout-sidebar"></i>
          <div >Discount Forms</div>
        </a>

        <ul class="menu-sub">
          <li class="menu-item">
            <a href="<?php echo e(route('add-discount-form')); ?>" class="menu-link">
              <div >Add Discount Forms</div>
            </a>
          </li>
          <li class="menu-item">
            <a href="<?php echo e(route('all-discount-form')); ?>" class="menu-link">
              <div >View All Discount Forms</div>
            </a>
          </li>

        </ul>
      </li>
      <!-- Front Pages -->
      <li class="menu-item">
        <a href="javascript:void(0);" class="menu-link menu-toggle">
          <i class="menu-icon tf-icons ti ti-files"></i>
          <div >Sales Partners</div>
        </a>
        <ul class="menu-sub">
          <li class="menu-item">
            <a href="<?php echo e(route('all-dealer')); ?>" class="menu-link">
              <div >All Dealers</div>
            </a>
          </li>
          <li class="menu-item">
            <a href="<?php echo e(route('add-dealer')); ?>" class="menu-link" >
              <div >Add Dealers</div>
            </a>
          </li>

        </ul>
      </li>

      <li class="menu-item">
        <a href="javascript:void(0);" class="menu-link menu-toggle">
          <i class="menu-icon tf-icons ti ti-id"></i>
          <div >Client Modules</div>
        </a>
        <ul class="menu-sub">

          <li class="menu-item">
            <a href="<?php echo e(route('all-clients')); ?>" class="menu-link" t>
              <div >All Clients</div>
            </a>
          </li>
          <li class="menu-item">
            <a href="<?php echo e(route('add-client')); ?>" class="menu-link" >
              <div >Add Client</div>
            </a>
          </li>
        </ul>
      </li>

      <!-- Apps & Pages -->


      <li class="menu-header small text-uppercase">
        <span class="menu-header-text">App Module</span>
      </li>

      <li class="menu-item">
        <a href="<?php echo e(route('all-banners')); ?>" class="menu-link">
          <i class="menu-icon tf-icons ti ti-brand-tabler"></i>
          <div >Banners</div>
        </a>
      </li>

      <!-- Academy menu end -->



      <li class="menu-item">
        <a href="<?php echo e(route('all-forms')); ?>" class="menu-link ">
          <i class="menu-icon tf-icons ti ti-file-description"></i>
          <div>Customer Query</div>
        </a>

      </li>
      <li class="menu-item">
        <a href="<?php echo e(route('all-partners')); ?>" class="menu-link ">
          <i class="menu-icon tf-icons ti ti-users"></i>
          <div>Affiliated Sales Partners</div>
        </a>

      </li>
      <li class="menu-header small text-uppercase">
        <span class="menu-header-text">Advance Options</span>
      </li>

      <li class="menu-item">
        <a href="<?php echo e(route('edit_profile')); ?>" class="menu-link">
          <i class="menu-icon tf-icons ti ti-mail"></i>
          <div >Edit porfile</div>
        </a>
      </li>

      <!-- Academy menu end -->



      <li class="menu-item">
        <a href="javascript:void(0);" class="menu-link ">
          <i class="menu-icon tf-icons ti ti-settings"></i>
          <div>Settings</div>
        </a>

      </li>
    </ul>
  </aside>
<?php /**PATH F:\Projects\hillview\hill-view\resources\views/backend_app/layouts/header.blade.php ENDPATH**/ ?>