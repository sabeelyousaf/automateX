<?php $__env->startSection('content'); ?>

<div class="layout-page">
    <!-- Navbar -->
    <?php echo $__env->make('backend_app.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- / Navbar -->

    <!-- Content wrapper -->
    <div class="content-wrapper">
      <!-- Content -->

      <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Client /</span> Update Client</h4>



        <div class="card">
          <div class="card-datatable table-responsive p-4">
            <form action="<?php echo e(route('update-client',['id'=>$data->id])); ?>" method="POST">
                <?php echo csrf_field(); ?>
            <h5 class="pb-3">Add New Client</h5>
            <div class="row">
                <div class="col-lg-6 col-sm-12 col-md-6">
                    <label for="">Name</label>
                    <input type="text" class="form-control" name="name" id="" value="<?php echo e($data->name); ?>">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-lg-6 col-sm-12 col-md-6">
                    <label for="">Father Name</label>
                    <input type="text" class="form-control" name="father_name" id="" value="<?php echo e($data->father_name); ?>">
                    <?php $__errorArgs = ['father_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


            </div>
            <div class="row mt-3">
                <div class="col-lg-6 col-sm-12 col-md-6">
                    <label for="">Nationality</label>
                    <input type="text" class="form-control" name="nationality" id="" value="<?php echo e($data->nationality); ?>">
                    <?php $__errorArgs = ['nationality'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-lg-6 col-sm-12 col-md-6">
                    <label for="">Email</label>
                    <input type="email" class="form-control" name="email" id="" value="<?php echo e($data->email); ?>">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

            </div>

            <div class="row mt-3">
                <div class="col-lg-6 col-sm-12 col-md-6">
                    <label for="">Address</label>
                    <input type="text" class="form-control" name="address" id="" value="<?php echo e($data->address); ?>">
                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-lg-6 col-sm-12 col-md-6">
                    <label for="">Phone Number</label>
                    <input type="number" name="phone_no" class="form-control"  id="" value="<?php echo e($data->phone_no); ?>">
                    <?php $__errorArgs = ['phone_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

            </div>

            <div class="row mt-3">
                <div class="col-lg-6 col-sm-12 col-md-6">
                    <label for="">Date of birth</label>
                    <input type="date" name="date_of_birth" class="form-control" value="<?php echo e($data->date_of_birth); ?>">
                       <?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                       <span class="text-danger"><?php echo e($message); ?></span>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-lg-6 col-sm-12 col-md-6">
                    <label for="">CNIC</label>
                    <input type="text"  data-inputmask="'mask': '99999-9999999-9'" class="form-control"  placeholder="XXXXX-XXXXXXX-X"  name="cnic" required="" value="<?php echo e($data->cnic); ?>" >
                       <?php $__errorArgs = ['cnic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                       <span class="text-danger"><?php echo e($message); ?></span>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


            </div>
            <div class="row mt-3">
                <div class="col-lg-6 col-sm-12 col-md-6">
                    <label for="">Assigned Dealer</label>
                    <select name="assigned_to" class="form-select" id="">
                        <option value="">Choose...</option>
                        <?php $__currentLoopData = $dealers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php if($data->assigned_to === $item->id): ?> selected <?php endif; ?> value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </select>
                       <?php $__errorArgs = ['assigned_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                       <span class="text-danger"><?php echo e($message); ?></span>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-lg-6 col-sm-12 col-md-6">
                    <label for="">Assign Files</label>
                    <div class="select2-success">
                        <?php
                        $selectedIds = json_decode($data->files);
                    ?>

                    <select id="select2Success" class="select2 form-select" name="files[]" multiple>
                        <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php echo e(in_array($item->id, $selectedIds) ? 'selected' : ''); ?>>
                                <?php echo e($item->form_no); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    </div>

                       <?php $__errorArgs = ['files'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                       <span class="text-danger"><?php echo e($message); ?></span>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


            </div>


            <div class="row mt-3">
                <div class="col-lg-6 col-sm-12 col-md-6">
                    <label for="">Nominee</label>
                    <input value="<?php echo e($data->nominee); ?>" type="text" name="nominee" class="form-control">
                       <?php $__errorArgs = ['nominee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                       <span class="text-danger"><?php echo e($message); ?></span>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-lg-6 col-sm-12 col-md-6">
                    <label for="">Nominee Relationship</label>
                    <div class="select2-success">
                        <input value="<?php echo e($data->nominee_relations); ?>" type="text" name="nominee_relationship" class="form-control">
                      </div>

                       <?php $__errorArgs = ['nominee_relationship'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                       <span class="text-danger"><?php echo e($message); ?></span>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


            </div>






            <div class="row mt-3">
                <div class="col-12">
                    <button class="btn btn-primary">Submit</button>
                </div>
            </div>
        </form>
          </div>
        </div>
        <!-- Modal to add new record -->

        <!--/ DataTable with Buttons -->



      </div>
      <!-- / Content -->

      <!-- Footer -->
  <?php echo $__env->make('backend_app.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- / Footer -->

      <div class="content-backdrop fade"></div>
    </div>
    <!-- Content wrapper -->
  </div>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/3/jquery.inputmask.bundle.js"></script>
  <script>
    $(":input").inputmask();

   </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend_app.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\hillview\hill-view\CRM\resources\views/backend_app/client/edit_client.blade.php ENDPATH**/ ?>