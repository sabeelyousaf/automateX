<?php $__env->startSection('content'); ?>

<div class="layout-page">
    <!-- Navbar -->
    <?php echo $__env->make('backend_app.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- / Navbar -->

    <!-- Content wrapper -->
    <div class="content-wrapper">
      <!-- Content -->

      <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Clients /</span> All Clients</h4>
        <div class="card p-3 mb-3">
            <div class="row">
                <div class="col-lg-4 col-sm-12 col-md-6">

            <label for="">Search Clients</label>
            <input type="text" id="searchInput" placeholder="Search Client" class="form-control mt-2">

        </div>
        </div>
        </div>
        <div class="row">
            <div class="col-12">
                <a href="<?php echo e(route('add-client')); ?>" class="btn btn-primary w-auto float-end mb-2">Add New Client +</a>
            </div>
        </div>

        <!-- DataTable with Buttons -->
        <div class="card">

            <div class="table-responsive text-nowrap">
                
                <table class="table">
                  <thead>
                    <tr class="text-nowrap">
                        <th><input type="checkbox" name="items[]"></th>
                        <th>Name </th>
                        
                        <th>Email </th>
                        <th>Address </th>

                        <th>Phone number</th>
                        <th>Date of birth.</th>
                        <th>Dealer Assign</th>

                        <th>Action</th>

                    </tr>
                </thead>
                    <tbody id="table-body">
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><input type="checkbox" name="items[]"></td>
                        <td><a href="<?php echo e(route('client-profile',['id'=>$item->id])); ?>"><?php echo e($item->name); ?></a></td>

                        <td>
                            <?php echo e($item->email); ?>

                        </td>
                        <td><?php echo e($item->address); ?></td>
                        <td><?php echo e($item->phone_no); ?></td>
                        <td><?php echo e($item->date_of_birth); ?></td>
                        <td><?php echo e($item->distributor->company); ?></td>


                        <td>  <div class="dropdown">
                            <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                              <i class="ti ti-dots-vertical"></i>
                            </button>
                            <div class="dropdown-menu">
                              <a class="dropdown-item" href="<?php echo e(route('edit-client',['id'=>$item->id])); ?>"
                                ><i class="ti ti-pencil me-1"></i> Edit</a
                              >
                              <a class="dropdown-item"  href="<?php echo e(route('delete-client',['id'=>$item->id])); ?>"
                                ><i class="ti ti-trash me-1"></i> Delete</a
                              >
                            </div>
                          </div></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
               </table>
          </div>
        </div>
        <div id="paginationContainer" class="float-end mt-3">
            <?php echo e($data->links()); ?>

         </div>
        <!-- Modal to add new record -->

        <!--/ DataTable with Buttons -->



      </div>
      <!-- / Content -->

      <!-- Footer -->
  <?php echo $__env->make('backend_app.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- / Footer -->

      <div class="content-backdrop fade"></div>
    </div>
    <!-- Content wrapper -->
  </div>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script>

    $(document).ready(function(){
      $('#searchInput').on('input', function(){
          var searchText = $(this).val();
          searchDiscountForm(searchText);
      });

      let route = '<?php echo e(route('search-dealers')); ?>';

      function searchDiscountForm(searchText) {
          // Perform GET request with searchText
          $.get(route, { search: searchText }, function(element) {
              $('#paginationContainer').html("");
              $("#table-body").empty();

              // Handle response data
              if (element.data.length === 0) {
                  $('#table-body').html('<h2 class="text-center primary-heading">No Result Found</h2>');
              } else {
                  $('#paginationContainer').html(element.pagination);
                  var html = '';

                  element.data.data.forEach(function (element) {
                      html += `   <tr>
                        <td><input type="checkbox" name="items[]"></td>
                        <td><a href="/client-profile/${element.id}">${element.name}</a></td>

                        <td>
                            ${element.email}
                        </td>
                        <td> ${element.address}</td>
                        <td> ${element.phone_no}</td>
                        <td> ${element.date_of_birth}</td>
                        <td> none</td>


                        <td>  <div class="dropdown">
                            <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                              <i class="ti ti-dots-vertical"></i>
                            </button>
                            <div class="dropdown-menu">
                              <a class="dropdown-item" href="/edit-client/${element.id}"
                                ><i class="ti ti-pencil me-1"></i> Edit</a
                              >
                              <a class="dropdown-item"  href="/delete-client/${element.id}"
                                ><i class="ti ti-trash me-1"></i> Delete</a
                              >
                            </div>
                          </div></td>
                    </tr>`;
                  });

                  $("#table-body").append(html);
              }
          });
      }


  });
  $(document).on('click', '.pagination a', function (event) {
      event.preventDefault();
      var page = $(this).attr('href').split('page=')[1];
      var searchValue = $('#searchInput').val();
      $.ajax({
          url: '/search-clients?page=' + page, // Modify the URL according to your route
      data: {'search':searchValue},
          beforeSend: function(){
          $('#paginationContainer').html("");
          $("#table-body").empty();
          $("#table-body").append(`
              <div class="text-center">
                  <div id="preloader2" class="spinner-grow text-success" role="status">
                      <span class="visually mx-5">Loading...</span>
                  </div>
              </div>
          `);
      },
          success: function (element) {

              $("#table-body").empty();
              $('#paginationContainer').html("");
              $('#paginationContainer').html(element.pagination);
                      // Handle the success response as needed


                      $('#paginationContainer').html("");
              $("#table-body").empty();

              // Handle response data
              if (element.data.length === 0) {
                  $('#products-area').html('<h2 class="text-center primary-heading">No Result Found</h2>');
              } else {
                  $('#paginationContainer').html(element.pagination);
                  var html = '';
                 products=element.data.data;


                 products.forEach(function (element) {
                      html += ` <tr>
                        <td><input type="checkbox" name="items[]"></td>
                        <td><a href="/client-profile/${element.id}">${element.name}</a></td>

                        <td>
                            ${element.email}
                        </td>
                        <td> ${element.address}</td>
                        <td> ${element.phone_no}</td>
                        <td> ${element.date_of_birth}</td>
                        <td> ${element.distributor.company}</td>


                        <td>  <div class="dropdown">
                            <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                              <i class="ti ti-dots-vertical"></i>
                            </button>
                            <div class="dropdown-menu">
                              <a class="dropdown-item" href="/edit-client/${element.id}"
                                ><i class="ti ti-pencil me-1"></i> Edit</a
                              >
                              <a class="dropdown-item"  href="/delete-client/${element.id}"
                                ><i class="ti ti-trash me-1"></i> Delete</a
                              >
                            </div>
                          </div></td>
                    </tr>`;
                  });

                  $("#table-body").append(html);
              }
                  },
                  error: function (error) {
                      // Handle errors if any
                      console.error(error);
                  }
      });
  });

</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend_app.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\hillview\hill-view\CRM\resources\views/backend_app/client/all_clients.blade.php ENDPATH**/ ?>