<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
   <?php
       $user=Auth::user();
   ?>
    <div class="app-brand demo">
      <a href="<?php echo e(route('dashboard')); ?>" class="app-brand-link py-5">
       <h4 class="fw-bold">AutomateX</h4>
      </a>

      <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto">
        <i class="ti menu-toggle-icon d-none d-xl-block ti-sm align-middle"></i>
        <i class="ti ti-x d-block d-xl-none ti-sm align-middle"></i>
      </a>
    </div>

    <div class="menu-inner-shadow"></div>
    <ul class="menu-inner py-1">
      <!-- Dashboards -->
      <li class="menu-item <?php echo e(Request::is('dashboard') ?'active':''); ?>">
        <a href="<?php echo e(route('dashboard')); ?>" class="menu-link" >
          <i class="menu-icon tf-icons ti ti-smart-home"></i>
          <div>Dashboards</div>
        </a>
      </li>

      <!-- Layouts -->
      <li class="menu-item <?php echo e(Request::is('add-files') || Request::is('all-files') ? 'active' : ''); ?>">

      <li class="menu-item <?php echo e(Request::is('add-files') || Request::is('all-files') ? 'open' : ''); ?>  ">
        <a href="javascript:void(0);" class="menu-link menu-toggle">
          <i class="menu-icon tf-icons ti ti-chart-pie"></i>
          <div >Tweets</div>
        </a>

        <ul class="menu-sub">
          <li class="menu-item <?php echo e(Request::is('add-files') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('add-files')); ?>" class="menu-link">
              <div >Add New Tweet</div>
            </a>
          </li>
          <li class="menu-item <?php echo e(Request::is('all-files') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('all-files')); ?>" class="menu-link">
              <div >View All Tweets</div>
            </a>
          </li>

        </ul>
      </li>
      <li class="menu-item <?php echo e(Request::is('pricing') ?'active':''); ?>">
        <a href="<?php echo e(route('pricing')); ?>" class="menu-link" >
          <i class="menu-icon tf-icons ti ti-smart-home"></i>
          <div>Pricing</div>
        </a>
      </li>

      
      <!-- Front Pages -->
      

      

      <!-- Apps & Pages -->


      
      <li class="menu-header small text-uppercase">
        <span class="menu-header-text">Advance Options</span>
      </li>

      <li class="menu-item <?php echo e(Request::is('edit-profile') ? 'active' : ''); ?>">
        <a href="<?php echo e(route('edit_profile')); ?>" class="menu-link">
          <i class="menu-icon tf-icons ti ti-mail"></i>
          <div >Edit porfile</div>
        </a>
      </li>

      <!-- Academy menu end -->



      <li class="menu-item">
        <a href="<?php echo e(route('setting-details')); ?>" class="menu-link ">
          <i class="menu-icon tf-icons ti ti-settings"></i>
          <div>Settings</div>
        </a>

      </li>
    </ul>
  </aside>
<?php /**PATH F:\Projects\twitter\CRM\resources\views/backend_app/layouts/header.blade.php ENDPATH**/ ?>