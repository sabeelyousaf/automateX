<?php $__env->startSection('content'); ?>

<div class="layout-page">
    <!-- Navbar -->

 <?php echo $__env->make('backend_app.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- / Navbar -->

    <!-- Content wrapper -->
    <div class="content-wrapper">
      <!-- Content -->

      <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">User Profile /</span> Profile</h4>

        <!-- Header -->
        <div class="row">
          <div class="col-12">
            <div class="card mb-4">
              <div class="user-profile-header-banner">
                <img src="https://img.freepik.com/premium-vector/abstract-sale-busioness-background-banner-design-multipurpose_1340-16819.jpg   " alt="Banner image" class="rounded-top" />
              </div>
              <div class="user-profile-header d-flex flex-column flex-sm-row text-sm-start text-center mb-4">
                <div class="flex-shrink-0 mt-n2 mx-sm-0 mx-auto">
                    <img
                    src="<?php echo e(asset('assets/img/avatars/avatar.png')); ?>"
                    alt="user image"
                    class="d-block h-auto ms-0 ms-sm-4 user-profile-img" />
                </div>
                <div class="flex-grow-1 mt-3 mt-sm-5">
                  <div
                    class="d-flex align-items-md-end align-items-sm-start align-items-center justify-content-md-between justify-content-start mx-4 flex-md-row flex-column gap-4">
                    <div class="user-profile-info">
                      <h4><?php echo e($data->name); ?></h4>
                      <ul
                        class="list-inline mb-0 d-flex align-items-center flex-wrap justify-content-sm-start justify-content-center gap-2">
                        <li class="list-inline-item d-flex gap-1">
                          <i class="ti ti-color-swatch"></i> Client
                        </li>
                        <li class="list-inline-item d-flex gap-1"><i class="ti ti-map-pin"></i> <?php echo e($data->address); ?></li>
                        <li class="list-inline-item d-flex gap-1">
                          <i class="ti ti-calendar"></i> Joined <?php echo e($data->created_at->format('i M Y')); ?>

                        </li>
                      </ul>
                    </div>
                    <a href="javascript:void(0)" class="btn btn-primary">
                      <i class="ti ti-check me-1"></i>Dealer:<?php echo e($data->distributor->name); ?>

                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!--/ Header -->

        <!-- Navbar pills -->
        <div class="row">
          <div class="col-md-12">
            <ul class="nav nav-pills flex-column flex-sm-row mb-4">
                <li class="nav-item me-2">
                  <a class="nav-link active" href="javascript:void(0);"
                    > Amounts  <i class="fas fa-arrow-alt-circle-right mx-2"></i></a
                  >
                  <li class="nav-item btn btn-label-primary   me-3">
                      <i class="fas fa-dollar-sign"></i><span class="fw-medium mx-2 text-heading ">Total Amount:</span> <span><?php echo e($total_amount); ?></span>
                    </li>
                    <li class="nav-item btn btn-label-warning me-3">
                      <i class="fas fa-dollar-sign"></i><span class="fw-medium mx-2 text-heading">Total Paid Amount:</span> <span><?php echo e($paid_amount); ?></span>
                    </li>
                    <li class="nav-item btn btn-label-danger me-3">
                      <i class="fas fa-dollar-sign"></i><span class="fw-medium mx-2 text-heading">Balance Amount:</span> <span><?php echo e($total_amount - $paid_amount); ?></span>
                    </li>
                </li>

              </ul>
          </div>
        </div>
        <!--/ Navbar pills -->

        <!-- User Profile Content -->
        <div class="row">
          <div class="col-xl-4 col-lg-5 col-md-5">
            <!-- About User -->
            <div class="card mb-4">
              <div class="card-body">
                <small class="card-text text-uppercase">About</small>
                <ul class="list-unstyled mb-4 mt-3">
                  <li class="d-flex align-items-center mb-3">
                    <i class="ti ti-user text-heading"></i
                    ><span class="fw-medium mx-2 text-heading">Full Name:</span> <span><?php echo e($data->name); ?></span>
                  </li>
                  <li class="d-flex align-items-center mb-3">
                    <i class="ti ti-user text-heading"></i
                    ><span class="fw-medium mx-2 text-heading">Father Name:</span> <span><?php echo e($data->father_name); ?></span>
                  </li>
                  <li class="d-flex align-items-center mb-3">
                    <i class="ti ti-check text-heading"></i
                    ><span class="fw-medium mx-2 text-heading">CNIC No:</span> <span><?php echo e($data->cnic_no); ?></span>
                  </li>
                  <li class="d-flex align-items-center mb-3">
                    <i class="ti ti-crown text-heading"></i
                    ><span class="fw-medium mx-2 text-heading">Company:</span> <span><?php echo e($data->company); ?></span>
                  </li>
                  <li class="d-flex align-items-center mb-3">
                    <i class="ti ti-flag text-heading"></i
                    ><span class="fw-medium mx-2 text-heading">Country:</span> <span><?php echo e($data->nationality); ?></span>
                  </li>
                  <li class="d-flex align-items-center mb-3">
                    <i class="ti ti-file-description text-heading"></i
                    ><span class="fw-medium mx-2 text-heading">Date of birth:</span> <span><?php echo e($data->date_of_birth); ?></span>
                  </li>
                </ul>
                <small class="card-text text-uppercase">Contacts</small>
                <ul class="list-unstyled mb-4 mt-3">
                  <li class="d-flex align-items-center mb-3">
                    <i class="ti ti-phone-call"></i><span class="fw-medium mx-2 text-heading">Contact:</span>
                    <span><?php echo e($data->phone_no); ?></span>
                  </li>
                  <li class="d-flex align-items-center mb-3">
                    <i class="ti ti-map-pin"></i><span class="fw-medium mx-2 text-heading">Address:</span>
                    <span><?php echo e($data->address); ?></span>
                  </li>
                  <li class="d-flex align-items-center mb-3">
                    <i class="ti ti-mail"></i><span class="fw-medium mx-2 text-heading">Email:</span>
                    <span><?php echo e($data->email); ?></span>
                  </li>
                </ul>

              </div>
            </div>

          </div>
          <div class="col-xl-8 col-lg-7 col-md-7">

            <!--/ Activity Timeline -->
            <div class="row">
              <!-- Connections -->
              <div class="col-lg-12 col-xl-12">
                <div class="card card-action mb-4">
                  <div class="card-header align-items-center">
                    <h5 class="card-action-title mb-0">Files</h5>
                    <div class="card-action-element">
                      <div class="dropdown">
                        <button
                          type="button"
                          class="btn dropdown-toggle hide-arrow p-0"
                          data-bs-toggle="dropdown"
                          aria-expanded="false">
                          <i class="ti ti-dots-vertical text-muted"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                          <li><a class="dropdown-item" href="javascript:void(0);">Share connections</a></li>
                          <li><a class="dropdown-item" href="javascript:void(0);">Suggest edits</a></li>
                          <li>
                            <hr class="dropdown-divider" />
                          </li>
                          <li><a class="dropdown-item" href="javascript:void(0);">Report bug</a></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="card-body">
                    <ul class="list-unstyled mb-0">
                        <?php
                           $filesData = json_decode($data->files);
                        ?>
                        <?php $__empty_1 = true; $__currentLoopData = $filesData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                        $file_data = DB::table('files')->where('id', $item)->first();
                        $ledger = DB::table('ledgers')->where('file_id', $item)->get();
                        if ($ledger === null) {
// If ledger is not found, set it to 0
$ledger = (object) ['paid_amount' => 0];
}
                    $paid_amount=0;
                    foreach ($ledger as $value){
                        $paid_amount+=$value->paid_amount;
                    }
                    $remaning_amount = $file_data->total_amount- $paid_amount;

                    ?>
                      <li class="mb-3 border-bottom pb-2">
                        <div class="d-flex align-items-start">
                          <div class="d-flex align-items-start">
                            <div class="s_no me-4"><h6><?php echo e($key); ?></h6></div>
                            <div class="avatar me-2">
                              <img src="<?php echo e(asset('assets/img/avatars/file.jpg')); ?>" alt="Avatar p-2" class="rounded-circle" />
                            </div>
                            <div class="me-2 ms-1">
                              <h6 class="mb-2"><a href="<?php echo e(route('file-data',['id'=>$file_data->id])); ?>"><?php echo e($file_data->form_no); ?> <span class="badge bg-label-info"><?php echo e($file_data->file_status); ?> </a></span></h6>
                                <small class="text-muted"><span class="badge bg-label-primary">Total Amount <?php echo e($file_data->total_amount); ?></span></small>
                                <small class="text-muted" ><span class="badge bg-label-warning">Paid Amount :<?php echo e($paid_amount); ?></span> </small>
                                <small class="text-muted" ><span class="badge bg-label-danger">Balance Amount :<?php if($remaning_amount): ?><?php echo e($remaning_amount); ?> <?php else: ?> Empty <?php endif; ?> </span></small>
                            </div>
                          </div>
                          <div class="ms-auto">
                            
                          </div>
                        </div>
                      </li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li>Empty</li>
                        <?php endif; ?>
                    </ul>
                  </div>
                </div>
              </div>
              <!--/ Connections -->
              <!-- Teams -->

              <!--/ Teams -->
            </div>
            <!-- Projects table -->

            <!--/ Projects table -->
          </div>
        </div>
        <!--/ User Profile Content -->
      </div>
      <!-- / Content -->

      <!-- Footer -->
   <?php echo $__env->make('backend_app.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- / Footer -->

      <div class="content-backdrop fade"></div>
    </div>
    <!-- Content wrapper -->
  </div>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('backend_app.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u247318372/domains/miyar.pk/public_html/hillview/resources/views/backend_app/client_profile.blade.php ENDPATH**/ ?>