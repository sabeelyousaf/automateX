<?php $__env->startSection('content'); ?>

<div class="layout-page">
    <!-- Navbar -->
    <?php echo $__env->make('backend_app.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    

    <div class="modal fade" id="bulk_action_modal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-simple modal-enable-otp modal-dialog-centered">
          <div class="modal-content p-3 p-md-5">
            <div class="modal-body">
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              <div class="text-center mb-4">
                <h3 class="mb-2">Assign Dealer</h3>

              </div>

              <form id="enableOTPForm" class="row g-3" action="#" method="post">
                <?php echo csrf_field(); ?>
                <div class="col-12">


                </div>
                <div class="col-12">
                    <label class="form-label" for="modalEnableOTPPhone">Dealers</label>
                    <div class="input-group py-2 mb-3">
                        <select class="form-select" id="dealer_assign">
                            <option value="">Choose...</option>
                            <?php $__currentLoopData = $dealers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dealer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dealer->id); ?>"><?php echo e($dealer->company); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>
                  </div>
                <div class="col-12">
                  <button type="button"  class="btn btn-outline-primary me-sm-3 me-1" id="dealer_btn">Assign</button>
                  <button
                    type="reset"
                    class="btn btn-label-secondary"
                    data-bs-dismiss="modal"
                    aria-label="Close">
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>







    <!-- Content wrapper -->
    <div class="content-wrapper">
      <!-- Content -->



      <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="py-3 mb-4"><span class="text-muted fw-light">Files /</span> All Files</h4>
<div class="row mb-3">
    <div class="col-12">
         <div class="card p-3">
        <div class="card-title">Manage Files</div>
        <form action="<?php echo e(route('assigned_dealers')); ?>" id="dealer_form" method="POST">
            <?php echo csrf_field(); ?>
        <div class="">
        <div class="d-flex flex-wrap flex-row">
            <label for="" class="mt-2 me-2">Bulk Action</label>
            <select name="dealer_id" class="form-select w-25" id="dealer_data">
                <option value="">Choose....</option>
                <option value="dealers">Dealers</option>
                <option value="status">Status</option>
                <option value="delete">Delete</option>

            </select>
            <button class="btn btn-primary mx-2" id="bulk_btn" type="button">Submit</button>
        </div>
    </form>



    <form action="<?php echo e(route('file_filer')); ?>"  method="POST" id="search-file">
        <?php echo csrf_field(); ?>
        <div class="row pt-2 mt-3 border-top">
            <div class="col-md-3">
                <label for="" class=" me-2 mb-1">Tracking no</label>
                <input type="text" class="form-control" placeholder="Enter Tracking no" name="tracking_no">
            </div>
            <div class="col-md-3">
                <label for="" class=" me-2 mb-1">App Form no</label>
                <input type="text" class="form-control" placeholder="Enter App Form no" name="form_no">
            </div>
            <div class="col-md-3">
                <label for="" class=" me-2 mb-1">Type</label>
                <select name="type" class="form-select " >
                    <option value="">Choose...</option>

                        <option value="residential">Residential</option>
                        <option value="commercial">Commercial</option>


                </select>
            </div>
            <div class="col-md-3">
                <label for="" class=" me-2 mb-1">Size</label>
                <input type="integer" placeholder="Enter Marla Size" class="form-control" name="size">
            </div>
            <div class="col-md-3 mt-3">
                <label for="" class=" me-2 mb-1">File Status</label>
                <select name="file_status" class="form-select" id="">
                    <option value="">Choose...</option>
                    <option value="open">Open</option>
                    <option value="closed">Closed</option>
                    <option value="blocked">Blocked</option>
                    <option value="processing">Processing</option>
                    <option value="reserved">Reserved</option>
                    <option value="ready">Ready</option>
                   </select>
            </div>

            <div class="col-md-3 mt-3">
                <label for="" class=" me-2 mb-1">Assigned Partners</label>
                <select name="dealer" class="form-select" id="">
                    <option value="">Choose...</option>
                    <?php $__currentLoopData = $dealers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dealer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($dealer->id); ?>"><?php echo e($dealer->company); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </select>
            </div>
            
            <div class="col-md-6 mt-3">
               <button type="button" class="btn btn-primary mt-4 ms-auto d-block"  id="filter_btn">Apply Filter</button>
            </div>
        </div>
    </form>
        </div>
        </div>
    </form>
    </div>
</div>
        <div class="row">
            <div class="col-12 py-2">
                <div class="dropdown float-end">
                    <button class="btn btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                     Actions
                    </button>
                    <ul class="dropdown-menu">
                      <li><a class="dropdown-item" href="<?php echo e(route('add-files')); ?>" class="btn btn-primary w-auto float-end mb-2">Add New File</a></li>
                      <li><a class="dropdown-item" id="delete_all" onclick="return confirm('Are you want to confirm to delete the files?')" class="btn btn-primary w-auto float-end mb-2 mx-2 text-white">Delete Files</a></li>

                    </ul>
                  </div>


            </div>
        </div>
        <!-- DataTable with Buttons -->



        <div class="card">

            <div class="table-responsive text-nowrap">
                
                <table class="table">
                  <thead>
                    <tr class="text-nowrap">
                        <th><input type="checkbox" id="checkItems"></th>
                        <th>Tracking no</th>
                        <th>App Form No </th>
                        <th>Id No</th>
                        <th>Security No</th>
                        <th>File Status</th>
                        <th>Type</th>
                        <th>Size</th>
                        <th>Unit</th>
                        <th>Total Amount</th>
                        <th>Paid Amount</th>
                        <th>Balance Amount</th>
                        <th>File Location</th>
                        <th>Assigned To</th>
                        <th>Client Name</th>
                        <th>Client Cnic</th>
                        <th>Action</th>

                    </tr>
                </thead>
                    <tbody id="table-body">
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php

                        $ledger = DB::table('ledgers')->where('file_id', $item->id)->get();
                        $paid_amount=0;

                        if ($ledger !== null) {

    foreach ($ledger as $key => $value) {

        $paid_amount+=$value->paid_amount;
    }


}


                        $remaning_amount = $item->total_amount- $paid_amount;

                    ?>
                      <th scope="row">
                        <input type="checkbox" class="all_products" name="items[]" value="<?php echo e($item->id); ?>">
                    </th>
                        <td><a data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="View Detail"  href="<?php echo e(route('file-data',['id'=>$item->id])); ?>"><?php echo e($item->hv_code); ?></a></td>
                        <td><?php echo e($item->form_no); ?></td>
                        <td><?php echo e($item->id_no); ?></td>
                        <td><?php echo e($item->security_no); ?></td>
                        <td>
                        <?php if($item->file_status==="open"): ?>
                       <span class="badge bg-success"> <?php echo e($item->file_status); ?></span>
                       <?php elseif($item->file_status=="blocked"): ?>
                       <span class="badge bg-danger"> <?php echo e($item->file_status); ?></span>
                       <?php elseif($item->file_status=="closed"): ?>
                       <span class="badge bg-danger"> <?php echo e($item->file_status); ?></span>
                       <?php elseif($item->file_status=="processing"): ?>
                       <span class="badge bg-warning"> <?php echo e($item->file_status); ?></span>
                       <?php elseif($item->file_status   =="reserved"): ?>
                       <span class="badge bg-info"> <?php echo e($item->file_status); ?></span>
                       <?php elseif($item->file_status   =="ready"): ?>
                       <span class="badge bg-primary"> <?php echo e($item->file_status); ?></span>
                        <?php endif; ?>
                        </td>
                        <td><?php echo e($item->type); ?></td>
                        <td><?php echo e($item->size); ?></td>
                        <td><?php echo e($item->unit); ?></td>
                        <td class="text-primary">Rs:<?php echo e(number_format($item->total_amount)); ?></td>
                        <td class="text-warning">Rs:<?php echo e(number_format($paid_amount)); ?></td>
                        <td class="text-danger">Rs:<?php echo e(number_format($remaning_amount)); ?></td>
                        <td><?php echo e($item->file_location); ?></td>
                        <td><span><?php if($item->distributor_id !== null): ?><?php echo e($item->dealer->company); ?> <?php endif; ?> </span><span data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Update Dealer"> <i  data-bs-toggle="modal" data-bs-target="#ledger_<?php echo e($item->id); ?>"  style="cursor: pointer" class="ti ti-pencil mx-1 text-warning"></i></span>
                            <div class="modal fade" id="ledger_<?php echo e($item->id); ?>" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog modal-simple modal-enable-otp modal-dialog-centered">
                                  <div class="modal-content p-3 p-md-5">
                                    <div class="modal-body">
                                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                      <div class="text-center mb-4">
                                        <h3 class="mb-2">Update Dealer</h3>
                                        <p>File Code:<?php echo e($item->hv_code); ?></p>
                                      </div>

                                      <form id="enableOTPForm" class="row g-3" action="<?php echo e(route('update-file-dealer',['id'=>$item->id])); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="col-12">


                                        </div>
                                        <div class="col-12">
                                            <label class="form-label" for="modalEnableOTPPhone">Dealers</label>
                                            <div class="input-group py-2 mb-3">
                                                <select name="distributor_id" class="form-select" id="">
                                                    <?php $__currentLoopData = $dealers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dealer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($dealer->id); ?>"><?php echo e($dealer->company); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </select>
                                            </div>
                                          </div>
                                        <div class="col-12">
                                          <button type="submit" class="btn btn-outline-primary me-sm-3 me-1">Submit</button>
                                          <button
                                            type="reset"
                                            class="btn btn-label-secondary"
                                            data-bs-dismiss="modal"
                                            aria-label="Close">
                                            Cancel
                                          </button>
                                        </div>
                                      </form>
                                    </div>
                                  </div>
                                </div>
                              </div>
                        </td>
                        <td>
                            <?php
                            $idAsString = strval($item->id);
                            $client = DB::table('clients')
                                            ->whereRaw('JSON_CONTAINS(files, ?)', [json_encode($idAsString)])->first();

                                            echo $client ? $client->name : '';
                            // Display the username if found, otherwise an empty string
                            ?>


                        </td>
                        <td>
<?php
     echo $client ? $client->cnic : '';
?>
                        </td>

                        <td>  <div class="dropdown">
                            <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                              <i class="ti ti-dots-vertical"></i>
                            </button>
                            <div class="dropdown-menu">
                              <a class="dropdown-item" href="<?php echo e(route('edit-file',['id'=>$item->id])); ?>"
                                ><i class="ti ti-pencil me-1"></i> Edit</a
                              >
                              <a class="dropdown-item"  href="<?php echo e(route('delete-file',['id'=>$item->id])); ?>"
                                ><i class="ti ti-trash me-1"></i> Delete</a
                              >
                            </div>
                          </div></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

               </table>

          </div>

        </div>
        <div id="paginationContainer" class="float-end mt-3">
            <?php echo e($data->links()); ?>

         </div>

      </div>
      <!-- / Content -->

      <!-- Footer -->
  <?php echo $__env->make('backend_app.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- / Footer -->

      <div class="content-backdrop fade"></div>
    </div>
    <!-- Content wrapper -->
  </div>

  <div class="modal fade" id="status_action_modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-simple modal-enable-otp modal-dialog-centered">
    <div class="modal-content p-3 p-md-5">
    <div class="modal-body">
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    <div class="text-center mb-4">
    <h3 class="mb-2">Update Status</h3>
    </div>


    <div class="col-12">
    <label class="form-label" for="modalEnableOTPPhone">Status</label>
    <div class="input-group py-2 mb-3">

        <form action="<?php echo e(route('bulk_status')); ?>" class="w-100" method="POST" id="status_form">
            <?php echo csrf_field(); ?>
    <select name="file_status" class="form-select" id="status_value">
    <option value="">Choose...</option>
    <option value="open">Open</option>
    <option value="closed">Closed</option>
                                <option value="blocked">Blocked</option>
                                <option value="processing">Processing</option>
                                <option value="reserved">Reserved</option>
                                <option value="ready">Ready</option>
                               </select>



                    </div>
                  </div>
                <div class="col-12">
                  <button type="button"  class="btn btn-outline-primary me-sm-3 me-1" id="status_btn">Update Status</button>
                  <button
                    type="reset"
                    class="btn btn-label-secondary"
                    data-bs-dismiss="modal"
                    aria-label="Close">
                    Cancel
                  </button>
                </div>
            </form>
            </div>
          </div>
        </div>
      </div>

      

  <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
  <script>
    $(document).ready(function(){



        $("#bulk_btn").click(function(){

    var checkedItems = $("input[name='items[]']:checked").map(function () {
    return $(this).val();
  }).get();

    let val = $("#dealer_data").val();
    if(val === "dealers"){
        $("#bulk_action_modal").modal('show');
    }
    else if(val==="status"){

        $("#status_action_modal").modal('show');

    }
    else if(val=== "delete") {

        if (confirm("Do you want to delete the Files?")) {

  $.ajax({
      url: "<?php echo e(route('delete_all')); ?>",
      method: 'GET',
      data: {
          items: checkedItems,
          datafrom:'files',
      },
      success: function (data) {
          if (data.success == true) {

              location.reload();

          } else if (data.success == false) {

              setTimeout(function () {

              }, 2000);
              location.reload();

          }
      }
  });
    }
}
});

        $("#filter_btn").click(function() {
    // Serialize form data
    let filter_data = $("#search-file").serialize();



    $.ajax({
    url: "<?php echo e(route('file_filer')); ?>",
    method: 'POST',
    data: filter_data,
    beforeSend: function() {
        $('#paginationContainer').html("");
        $("#table-body").empty();
        $("#table-body").append(`
            <div class="text-center">
                <div id="preloader2" class="spinner-grow text-success" role="status">
                    <span class="visually mx-5">Loading...</span>
                </div>
            </div>
        `);
    },
    success: function(response) {
        console.log(response);
        let html='';

    },
    error: function(xhr, status, error) {
        console.error(xhr.responseText);
    }
});



});


$("#status_btn").click(function(){
        // Get the selected dealer ID
        var select_status = $("#status_val").val();
        // Get the selected items
        var checkedItems = $("input[name='items[]']:checked").map(function () {
            return $(this).val();
        }).get();
        // Append values to the form

        // Append selected items as hidden inputs
        checkedItems.forEach(function (item) {
            $("<input>").attr({
                type: "hidden",
                name: "selected_items[]",
                value: item
            }).appendTo("#status_form");
        });
        $("<input>").attr({
            type:"hidden",
            name:"status",
            value:select_status
        }).appendTo("#status_form");

        $("#status_form").submit();
    });

    // Dealer BTN
   $("#dealer_btn").click(function(){
        // Get the selected dealer ID
        var selectedDealer = $("#dealer_assign").val();
        // Get the selected items
        var checkedItems = $("input[name='items[]']:checked").map(function () {
            return $(this).val();
        }).get();
        // Append values to the form
        $("#dealer_assign").val(selectedDealer);
        // Append selected items as hidden inputs
        checkedItems.forEach(function (item) {
            $("<input>").attr({
                type: "hidden",
                name: "selected_items[]",
                value: item
            }).appendTo("#dealer_form");
        });
        $("<input>").attr({
            type:"hidden",
            name:"dealer_id",
            value:selectedDealer
        }).appendTo("#dealer_form");

        $("#dealer_form").submit();
    });

    //


          $('#checkItems').on('click', function(e) {
              // e.preventDefault();
              $('.all_products').each(function() {
                  $(this).prop('checked', !$(this).prop('checked'));
              });
          });
      });
      $("#delete_all").click(() => {

  var checkedItems = $("input[name='items[]']:checked").map(function () {
      return $(this).val();
  }).get();



  $.ajax({
      url: "<?php echo e(route('delete_all')); ?>",
      method: 'GET',
      data: {
          items: checkedItems,
          datafrom:'files',
      },
      success: function (data) {
          if (data.success == true) {

              location.reload();

          } else if (data.success == false) {

              setTimeout(function () {

              }, 2000);
              location.reload();

          }
      }
  });

});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend_app.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\hillview\hill-view\Latest\crm\resources\views/backend_app/all_files.blade.php ENDPATH**/ ?>