<footer class="content-footer footer bg-footer-theme">
    <div class="container-xxl">
      <div
        class="footer-container d-flex align-items-center justify-content-between py-2 flex-md-row flex-column">
        <div>
          ©
          <script>
            document.write(new Date().getFullYear());
          </script>
          , made by <a href="#" target="_blank" class="fw-medium">KNS Technologies</a>
        </div>

      </div>
    </div>
  </footer>
<?php /**PATH /home/u247318372/domains/miyar.pk/public_html/hillview/resources/views/backend_app/layouts/footer.blade.php ENDPATH**/ ?>