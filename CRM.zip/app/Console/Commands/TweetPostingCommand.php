<?php

namespace App\Console\Commands;

use App\Models\Setting;
use App\Models\Tweet;
use Illuminate\Console\Command;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\HandlerStack;
use GuzzleHttp\Subscriber\Oauth\Oauth1;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TweetPostingCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:tweet-posting-command';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     */
    public function handle()
{

    $baseUrl = 'https://api.twitter.com/2/tweets';
    $tweets = Tweet::where('status', 0)->get();

    foreach ($tweets as $tweet) {
        // Check if the tweet's date is today and if the tweet's time matches the current time

            $key_detail = Setting::where('user_id',$tweet->user_id)->first();

            $client = new Client([
                'base_uri' => $baseUrl,
                'auth' => [
                    $key_detail->consumer_key,
                    $key_detail->consumer_secret,
                    $key_detail->consumer_access_token,
                    $key_detail->consumer_token_secreat
                ]
            ]);

            try {
                // Make the POST request
                $response = $client->post('', [
                    'json' => ['text' => $tweet->text]
                ]);

                // Handle the response data as needed
                $this->info('Tweet posted successfully: ' . $tweet->text);

            } catch (RequestException $e) {
                // Handle request errors
                $this->error('Tweet posting failed: ' . $e->getMessage());
            }

    }
}
}
