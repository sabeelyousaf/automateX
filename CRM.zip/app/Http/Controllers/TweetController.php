<?php

namespace App\Http\Controllers;
use App\Models\Tweet;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\HandlerStack;
use GuzzleHttp\Subscriber\Oauth\Oauth1;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
class TweetController extends Controller
{

    public function postTweet(Request $request)
    {
        // Twitter API base URL
        $baseUrl = 'https://api.twitter.com/2/tweets';

        // Your Twitter API credentials
        $consumerKey = '1FiDe1soyGbx6sK8cuqHqT0Lq';
        $consumerSecret = 'l2zBIb3zqMsY2prB1Ow6QxIMfe9RpKA8S2lfe6BWm1ZqhJtaey';
        $accessToken = '1774182005938311168-8bE9dOGe51YVPHUBC50gEstnlphfZV';
        $accessTokenSecret = 'ueHgiyTUm8vqXnknG9snXJvEDwDuG6BUndXONFZaBoEVp';

        // POST data (text you wish to Tweet)
        $data = [
            'text' => $request->text,
        ];

        // Initialize Guzzle client with OAuth1 authentication
        $stack = HandlerStack::create();
        $middleware = new Oauth1([
            'consumer_key' => $consumerKey,
            'consumer_secret' => $consumerSecret,
            'token' => $accessToken,
            'token_secret' => $accessTokenSecret
        ]);

        $stack->push($middleware);

        $client = new Client([
            'base_uri' => $baseUrl,
            'handler' => $stack,
            'auth' => 'oauth'
        ]);

        try {
            // Make the POST request
            $response = $client->post('', [
                'json' => $data
            ]);

            // Get the response body
            $responseData = json_decode($response->getBody()->getContents(), true); // Decode JSON response
            $text = $responseData['data']['text']; // Access text from response data

            // Handle the response data as needed
            return back()->with('success','New Tweet has been created successfully');
        } catch (RequestException $e) {
            // Handle request errors
            if ($e->hasResponse()) {
                $errorResponse = $e->getResponse();
                $errorMessage = $errorResponse->getBody()->getContents();
                dd($errorMessage);
            } else {
                dd($e->getMessage());
            }
        }
    }

}
